import SeatSelect from "./SeatSelect";

export default SeatSelect;